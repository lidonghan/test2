/* Touch Screen driver for aur3852 Platform
 *
 * Copyright (C) 2010 rock-chip, Inc.
 *
 *
 *
 * This file is free software; you can redistribute it and/or
 * modify it under the terms of the GNU  General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This file is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 */


#include <linux/input.h>
#include <linux/slab.h>
#include <asm/io.h>
#include <asm/types.h>
#include <asm/uaccess.h>


#include <linux/timer.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/hrtimer.h>
#include <linux/input.h>
#include <linux/i2c.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <linux/workqueue.h>

#include <linux/io.h>
#include <linux/ioport.h>
#include <linux/input-polldev.h>
#include <linux/earlysuspend.h>

#include <linux/init.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/poll.h>

#include <linux/delay.h>
#include <linux/input/mt.h>
#include <mach/iomux.h>
#include <mach/gpio.h>
#include <mach/board.h>
#include <linux/wakelock.h>
#include "aur3852.h"

static struct wake_lock ts_update_wake_lock;

MODULE_LICENSE("Dual BSD/GPL");

#define AUR3852_I2C_TS_NAME "aur3852_ts"
#define DRIVER_VERSION "v1.0"


#define TOUCH_RESET_PIN  RK29_PIN6_PC3
#define TOUCH_INT_PIN         RK29_PIN0_PA2

#define  AUR3852_I2C_SPEED (300*1000)
#define  AUR3852_I2C_ADD 0x05


//===================
#define TS_MIN_X 0
#define TS_MAX_X ((15-1)*64)	//ͨ��������ÿCELLֵ
#define TS_MIN_Y 0
#define TS_MAX_Y ((10-1)*64)

#define LCD_MAX_WIDTH 800
#define LCD_MAX_HEIGH 480
//=================

struct aur3852_ts_priv{
	uint16_t addr;
	struct i2c_client *client;
	struct input_dev *input_dev;
	int use_irq;
	int irq;
	struct hrtimer timer;
	struct work_struct work;
	struct early_suspend early_suspend;
};

//==========
static struct workqueue_struct *aur3852_wq;
struct aur3852_ts_priv *ts_aur3852_dev;
int ts_init_ok =0;
char need_time_check;
//=============


//=====================
#define MAX_BUFFER_SIZE	0x4040


enum _chip_state  //����������ж�״̬����
{
	NORMAL_PIONT_STATE =0,
	AUR_START_RSPD,		//START REPORT
	AUR_STOP,					//STOP MOD
	AUR_RST	,					//REST MOD
	AUR_CHECK_ISP_VER,
	AUR_READ_FLASHINFO,
	AUR_READ_CSP,
	AUR_EREASY_FLASH,
	AUR_WRITE_OPDF,     //Write One Page of Data to Flash
	AUR_WRITE_OPPF,
	AUR_GET_PP
};
enum _chip_state  chip_state = NORMAL_PIONT_STATE;
char respond_rsut =-1;
static int isupdateflag=0;
static int  firmware_update_status =0;
//static int flash_type = 0;
int AUR_PARA_ADDR;
int AUR_PARA_CNT;
int AUR_APROM_SIZE;
//int AUR_PAGE_SIZE;
/*struct flash_info{
	int size;
	int start_page;
	int end_page;
};*/
struct flash_info{
	unsigned short page_size;
	unsigned char start_page;
	unsigned char end_page;
	unsigned char total_page;
}__attribute__((packed));
//static struct flash_info *aur_flash_info;
//=================
//�����̼������ӿ�
#define PACKAGECODE_CHECK_ISPVER  0x81
#define COMMAND_ISP_GETFWVER      0x3A
#define RESPONCODE_CHECK_ISPVER   0x83

#define PACKAGECODE_GET_FLASHINFO 0x82
#define COMMAND_GET_FLASHINFO     0x3D
#define RESPONCODE_GET_FLASHINFO  0x85

#define PACKAGECODE_ERASE_FLASH   0x81
#define COMMAND_ERASE_FLASH       0x82
#define RESPONCODE_ERASE_FLASH    0x81

#define FIRSTCODE_DOWNLOAD_PAGEDATA  0xC1
#define COMMAND_DATA_IN               0x83
#define MIDCODE_DOWNLOAD_PAGEDATA    0x60
#define LASTCODE_DOWNLOAD_PAGEDATA   0x20
#define RESPONCODE_DOWNLOAD_PAGEDATA 0x83

#define PACKAGECODE_WRITE_PAGEDATA   0x82
#define COMMAND_WRITE_PAGEDATA        0X87
#define RESPONCODE_WRITE_PAGEDATA     0x81

#define TYPE_FLASH_AP     0x00
#define TYPE_FLASH_PP     0x01
#define TYPE_FLASH_APPP   0x02
#define TYPE_FLASH_CMOD   0x31
#define TYPE_FLASH_PPCMOD 0x32
#define TYPE_FLASH_ALL    0x33

#define OPERAT_SUCESS   0X80
#define COMMAND_UNKNOW  0x81
#define OPERAT_FAIL     0x82

#define BL_MODE  0xa0
#define PREFIXCODE   0x80
#define DATA_LEN (32)
#define DATA_CTRL_BYTE_START	0x60
#define DATA_CTRL_BYTE_END      0x20

#define AUR_PAGE_SIZE 256

static int aur3852_transfer(u8 buf[], u16 flag, unsigned len)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	int ret;

	priv = ts_aur3852_dev;

	msg[0].addr = priv->client->addr;
	msg[0].flags = flag;
	msg[0].len = len;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = buf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	return ret;

}
static int Check_ISP_Version(unsigned char *buf)
{
	uint8_t Wrbuf[2];
	uint8_t rdbuf[5];
	int ret ;
	int i=0;

	printk("Check ISP Version enter\n");

//	__gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
//    msleep(3);
//    __gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
//   	msleep(1);

	Wrbuf[0] = PACKAGECODE_CHECK_ISPVER;
	Wrbuf[1] = COMMAND_ISP_GETFWVER;

	ret = aur3852_transfer(Wrbuf,0,2);
	if(ret < 0)
	{
		printk("transfer write get ver cmd fail\n");
		return -1;
	}

   	msleep(1000);
retry:
	ret = aur3852_transfer(rdbuf,I2C_M_RD,5);
	if(ret < 0)
	{
		printk("transfer read get ver cmd fail\n");
		return -1;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		if(++i<5)
			goto retry;

		printk("get ver failed:rdbuf[0]=%02x, rdbuf[1]=%02x, rdbuf[2]=%02x, rdbuf[3]=%02x, rdbuf[4]=%02x\n",
		rdbuf[0], rdbuf[1], rdbuf[2], rdbuf[3], rdbuf[4]);
		return -1;
	}
	printk("get ver success:rdbuf[0]=%02x, rdbuf[1]=%02x, rdbuf[2]=%02x, rdbuf[3]=%02x, rdbuf[4]=%02x\n",
	rdbuf[0], rdbuf[1], rdbuf[2], rdbuf[3], rdbuf[4]);
	memcpy(buf,&rdbuf[2],3);
	return 0;

}
static int Check_ISP_AE_Version(unsigned char *buf)
{
	uint8_t Wrbuf[2];
	uint8_t rdbuf[8];
	int ret ;
	int i=0;

	printk("Check ISP Version enter\n");

//	__gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
//    msleep(3);
//    __gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
//   	msleep(1);

	Wrbuf[0] = PACKAGECODE_CHECK_ISPVER;
	Wrbuf[1] = 0X3b;

	ret = aur3852_transfer(Wrbuf,0,2);
	if(ret < 0)
	{
		printk("transfer write get ver cmd fail\n");
		return -1;
	}

   	msleep(1000);
retry:
	ret = aur3852_transfer(rdbuf,I2C_M_RD,8);
	if(ret < 0)
	{
		printk("transfer read get ver cmd fail\n");
		return -1;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		if(++i<5)
			goto retry;

		printk("get ver failed:rdbuf[0]=%02x, rdbuf[1]=%02x, rdbuf[2]=%02x, rdbuf[3]=%02x, rdbuf[4]=%02x\n",
		rdbuf[0], rdbuf[1], rdbuf[2], rdbuf[3], rdbuf[4]);
		return -1;
	}
	printk("get ver success:rdbuf[0]=%02x, rdbuf[1]=%02x, rdbuf[2]=%02x, rdbuf[3]=%02x, rdbuf[4]=%02x,rdbuf[5]=%02x\n",
	rdbuf[0], rdbuf[1], rdbuf[2], rdbuf[3], rdbuf[4],rdbuf[5]);
	memcpy(buf,&rdbuf[2],6);
	return 0;

}
static int enter_bootloader(void)
{
	int ret;
	unsigned char enter_bootloader_cmd[2] = {0x81, 0x12};

	ret = aur3852_transfer(enter_bootloader_cmd,0,2);
	if(ret < 0)
	{
		printk("write enter bootloader cmd error:%d\n", ret);
		return -1;
	}
	msleep(20);
	return 0;
}
/*Read Parameter Page Information*/
static int Read_flash_info(u8 type,unsigned char *buf)
{
	uint8_t Wrbuf[3];
	uint8_t rdbuf[6];
	int ret;

	Wrbuf[0] = 0x82;
	Wrbuf[1] = 0x3d;
	Wrbuf[2] = type;

	ret = aur3852_transfer(Wrbuf,0,sizeof(Wrbuf));
	if(ret < 0)
	{
		printk("write get flash info cmd failed !\n");
		return ret;
	}
	msleep(1000);

	ret = aur3852_transfer(rdbuf,I2C_M_RD,6);
	if(ret < 0)
	{
		printk("read get flash info receive response failed !\n");
		return ret;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		printk("get flash info receive response error, prefixcode=0x%02x\n", rdbuf[0]);
		return -1;
	}
	memcpy(buf,&rdbuf[2],4);
	return 0;

}

/*Erase All Application Code Sector Pages*/
static int Erase_flash(u8 type)
{
	uint8_t Wrbuf[3];
	uint8_t rdbuf[2];
	int ret ;

	Wrbuf[0] = 0x82;
	Wrbuf[1] = 0x82;
	Wrbuf[2] = type;

	ret = aur3852_transfer(Wrbuf,0,sizeof(Wrbuf));
	if(ret<0)
	{
		printk("write isp erease all cmd error:%d\n", ret);
		return -1;
	}
	msleep(5000);
	ret = aur3852_transfer(rdbuf,I2C_M_RD,2);
	if(ret < 0)
	{
		printk("read get erase receive response failed !\n");
		return ret;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		printk("erase receive response error, prefixcode=0x%02x\n", rdbuf[0]);
		return -1;
	}
	printk("isp erease all ok !\n");
	return 0;
}


/* Download One Page of Data */
int Download_One_Page(int pagesize,unsigned char *buf)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t rdbuf[4],Wrbuf[33]={0};
	char i,j;
	unsigned char ctrl_byte;
	unsigned char *ptr;
	int ret ;
	int trans_per_page;

	trans_per_page = pagesize/DATA_LEN;

	Wrbuf[0] = 0xc1;
	Wrbuf[1] = 0x83;
	ptr = buf;

	ret = aur3852_transfer(Wrbuf,0,2);
	if(ret<0)
	{
		printk("write isp data in cmd error:%d\n", ret);
		return ret;
	}
	msleep(50);

	for (i=0;i<trans_per_page;i++)
	{
		memset(Wrbuf,0,sizeof(Wrbuf));
		i == (trans_per_page - 1)/*last page*/ ? (ctrl_byte = DATA_CTRL_BYTE_END) : (ctrl_byte = DATA_CTRL_BYTE_START);
		Wrbuf[0] = ctrl_byte;
		memcpy(&Wrbuf[1],ptr,DATA_LEN);
		ptr += DATA_LEN;

		ret = aur3852_transfer(Wrbuf,0,DATA_LEN+1);
		if(ret<0)
		{
			printk("write isp data in data error:%d\n", ret);
			return -1;
		}
		msleep(10);
#if 0
			int k;
			for(k = 0; k < DATA_LEN + 1; k++)
			{
				printk("%02x ",buf[k]);
			}
			printk("\n");
#endif
	}

	ret = aur3852_transfer(rdbuf,I2C_M_RD,4);
	if(ret<0)
	{
		printk("Download_One_Page receive response failed !\n");
		return ret;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		printk("AUR3852 %s error\n",__FUNCTION__);
		return -1;
	}
	return 0;
}

/*Write One Page of Data to Flash*/
int Write_One_Page(u8 pageNum)
{
	uint8_t Wrbuf[3];
	uint8_t rdbuf[2];
	int ret;
	Wrbuf[0] = PACKAGECODE_WRITE_PAGEDATA;
	Wrbuf[1] = COMMAND_WRITE_PAGEDATA;
	Wrbuf[2] = pageNum;

	ret = aur3852_transfer(Wrbuf,0,sizeof(Wrbuf));
	if(ret<0)
	{
		printk("write isp program veri cmd error:%d\n", ret);
		return -1;
	}
	msleep(50);

	ret = aur3852_transfer(rdbuf,I2C_M_RD,sizeof(rdbuf));
	if(ret<0)
	{
		printk("Write_One_Page receive response failed !\n");
		return ret;
	}
	if(rdbuf[1] != PREFIXCODE)
	{
		printk("AUR3852 %s error\n",__FUNCTION__);
		return -1;
	}

	return 0;

}

/*Write One Page of Parameter to Flash*/
int Write_One_Page_Parameter(char pageNum)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[3];

	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x82;
	Wrbuf[1] = 0x84;
	Wrbuf[2] = pageNum;
	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 3;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);

	chip_state = AUR_WRITE_OPPF;

	respond_rsut= -1;
	do{
		msleep(5);
		}while(respond_rsut<0);

	return 0;

}

/*Get Parameter Page*/
int Get_Parameter_Page(char pageNum)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[3];

	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x82;
	Wrbuf[1] = 0x86;
	Wrbuf[2] = pageNum;
	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 3;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	chip_state = AUR_GET_PP;

		respond_rsut= -1;
	do{
		msleep(5);
		}while(respond_rsut<0);

	return 0;

}

int exit_ISP(void)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[2];

	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x81;
	Wrbuf[1] = 0x8f;

	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 2;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	if(ret<0)
		return ret;

	msleep(2000);
	return 0;
}
extern unsigned char aur3852_data[30613];

int touchfirmwareupdate(void)
{
	static char *buf;
    struct file *fp;
    mm_segment_t fs;
    loff_t pos;
    int code_length;
    int checksumorign;
	int page_size;
	int start_page_num;//��ʼҳ��ַ
	int end_page_num;//����ҳ��ַ
	int total_page_num;//����ҳ��ַ
	int i;
	int ret;
	unsigned char ver_buf[5];
	unsigned char databuf[5];
	unsigned char *pdata;
	struct flash_info ap_to_pp;

    printk("touchfirmwareupdate enter\n");
//    wake_lock(&ts_update_wake_lock);	//��������ֹ�������˯��
	//pdata = aur3852_data;
 	if(Check_ISP_Version(ver_buf)<0)
 	{
		goto init;
	}
	if(ver_buf[0] < BL_MODE)
	{
init:
		ret = enter_bootloader();//enter bootloader
		if(ret < 0)
			goto error;
		if(Check_ISP_Version(ver_buf)<0)
		{
			goto error;
		}
		printk("Already entered bootloader mode!\n");
		printk("bootloader version:0x%02x, 0x%02x, 0x%02x\n", ver_buf[0], ver_buf[1], ver_buf[2]);

		if(ver_buf[2] < 0x05)
		{
			printk("\nThe bootloader version is too old, it can't upgrade firmware!\n");
			goto exit;
		}
	}
	else
	{
		printk("Already entered bootloader mode!\n");
		if(Check_ISP_Version(ver_buf)<0)
		{
			goto error;
		}
		if(ver_buf[2] < 0x05)
		{
			printk("\nThe bootloader version is too old, it can't upgrade firmware!\n");
			goto exit;
		}
	}
	//updata ap and pp olny
	//printk("(unsigned char*)&ap_to_pp is 0x%08x\n",(unsigned char*)&ap_to_pp);
	if(Read_flash_info(TYPE_FLASH_APPP,databuf)<0)//(unsigned char*)&ap_to_pp)<0)
	{
	 	goto error;
	}
//	printk("ap_to_pp.page_size = 0x%04x,ap_to_pp.start_page = 0x02x,ap_to_pp.end_page = 0x02x\n",ap_to_pp.page_size,
//		ap_to_pp.start_page,ap_to_pp.end_page);

	page_size = databuf[1]<<8|databuf[0];//ap_to_pp.page_size;
	start_page_num = databuf[2];//ap_to_pp.start_page;
	end_page_num = databuf[3];//ap_to_pp.end_page;
	total_page_num = end_page_num - start_page_num +1;
		printk("page_size = 0x%04x,start_page_num = 0x%02x,end_page_num = 0x%02x\n",page_size,
		start_page_num,end_page_num);

	if(Erase_flash(TYPE_FLASH_APPP)<0)
 	{
		goto error;
	}

	for (i=0;i<total_page_num;i++)
	{
		if(0< Download_One_Page(page_size,aur3852_data+i*page_size))
		{
			goto error;
		}

		if(0< Write_One_Page(i))
		{
			goto error;
		}
		printk("write the %d page ok\n",i);
	}
	ret = exit_ISP();
	if(ret < 0)
		goto error;
	Check_ISP_Version(ver_buf);
 //  wake_unlock(&ts_update_wake_lock);
	printk("touchpanel AUR3852 firmware update OK\n");
	//kfree(buf);
	__gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
	msleep(50);
	printk("touchpanel reset after progaram\n");
	__gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
	msleep(500);
	return 0;

exit:
	ret = exit_ISP();
	if(ret < 0)
		goto error;

//	   wake_unlock(&ts_update_wake_lock);
	//	kfree(buf);
	__gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
    msleep(50);
    __gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
   	msleep(500);
    return -1;

error:
//	wake_unlock(&ts_update_wake_lock);
	//kfree(buf);
	printk("error here\n");
	__gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
    msleep(50);
    __gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
   	msleep(500);
    return -1;
}




static ssize_t aur3852_firmware_update(struct device_driver *_drv, const char *_buf, size_t _count)
{
    if( !strncmp(_buf,"update" , strlen("update")) )
    	{
				firmware_update_status =1;
				isupdateflag =1;
				if(touchfirmwareupdate()==0)
					{
					firmware_update_status =2;
					printk("successful enter\n");
					}
				else
					{
					firmware_update_status =3;
					printk("failed enter\n");
					}

				isupdateflag =0;
			}
//�ն˲��Խӿ�
    if( !strncmp(_buf,"successful" , strlen("successful")) )
				firmware_update_status =2;

    if( !strncmp(_buf,"failed" , strlen("failed")) )
				firmware_update_status =3;
 return 0;
}

static ssize_t aur3852_firmware_state(struct device_driver *_drv,char *_buf)
{
	if(firmware_update_status ==1)
		return sprintf(_buf,"updating");

	if(firmware_update_status == 2)
		return sprintf(_buf,"successful");

	if(firmware_update_status ==3)
		return sprintf(_buf,"failed");
 return 0;
}



//==========================================================
/*Read Parameter Page Information*/
int AUR3852_REPORT_START(void)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[3];
	uint8_t Rdbuf[3];
	
	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x82;
	Wrbuf[1] = 0x29;
	Wrbuf[2] = 0x01;
	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 3;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	if(ret < 0)
	{
		printk("AUR3852_REPORT_START write fail\n");
	}
	//msleep(200);
	chip_state = AUR_START_RSPD;
//	chip_state = NORMAL_PIONT_STATE;

	/*
	while(!respond_rsut)
	{
		mdelay(1);
	}

	respond_rsut = -1;
	chip_state = NORMAL_PIONT_STATE;
	*/
	return 0;

}

#if 0
int AUR3852_STOP(void)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[2];

	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x81;
	Wrbuf[1] = 0x13;
	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 2;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	chip_state = AUR_STOP;

	return 0;

}
#endif

#if 0
int AUR3852_RST(void)
{
	struct aur3852_ts_priv *priv;
	struct i2c_msg msg[2];
	uint8_t Wrbuf[2];

	int ret ;
	priv = ts_aur3852_dev;
	Wrbuf[0] = 0x81;
	Wrbuf[1] = 0x11;
	msg[0].addr = priv->client->addr;
	msg[0].flags = 0;
	msg[0].len = 2;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Wrbuf;

	ret = i2c_transfer(priv->client->adapter, msg, 1);
	chip_state = AUR_RST;

	return 0;

}
#endif
//===========================================================

static enum hrtimer_restart AUR3852_ts_timer_func(struct hrtimer *timer)
{
	struct aur3852_ts_priv *priv = container_of(timer, struct aur3852_ts_priv, timer);
	printk("AUR3852_ts_timer_func\n");
	if (!gpio_get_value (TOUCH_INT_PIN))
		{
			need_time_check = 0;
			queue_work(aur3852_wq, &priv->work);
		}
		//hrtimer_start(&priv->timer, ktime_set(0, 10000000), HRTIMER_MODE_REL);
		return HRTIMER_NORESTART;

}



#ifdef CONFIG_HAS_EARLYSUSPEND
static void aur3852_ts_suspend(struct early_suspend *h)
{
	int ret;
	struct aur3852_ts_priv *priv;
	priv = container_of(h, struct aur3852_ts_priv, early_suspend);

	printk("aur3852_ts_suspend\n");

	//AUR3852_STOP( );

	if (priv->irq)
	disable_irq_nosync(priv->irq);
	//else
	//hrtimer_cancel(&priv->timer);

	ret = cancel_work_sync(&priv->work);
	if (ret && priv->irq) /* if work was pending disable-count is now 2 */
		{
		printk("aur3852_ts_suspend_cancel_work failed!!!\n");
		enable_irq(priv->irq);
		return ;
		}

	return ;

}


static void aur3852_ts_resume(struct early_suspend *h)
{
    struct aur3852_ts_priv *priv;
    priv = container_of(h, struct aur3852_ts_priv, early_suspend);


	printk("aur3852_ts_resume\n");


	if (priv->irq)
		enable_irq(priv->irq);

		//hrtimer_start(&priv->timer, ktime_set(0, 100000000), HRTIMER_MODE_REL);
		//AUR3852_RST();

		gpio_set_value(TOUCH_RESET_PIN,GPIO_LOW);
    msleep(10);
    gpio_set_value(TOUCH_RESET_PIN,GPIO_HIGH);
		msleep(50);
		AUR3852_REPORT_START() ;
	return ;
}

/*
static struct early_suspend aur3852_early_suspend = {
	.suspend = aur3852_ts_suspend,
	.resume = aur3852_ts_resume,
	.level = EARLY_SUSPEND_LEVEL_BLANK_SCREEN - 1,
};
*/
#endif


static void aur3852_ts_work(/*void* unused*/struct work_struct *work)
{
	struct aur3852_ts_priv *priv = container_of(work,struct aur3852_ts_priv,work);

	struct i2c_msg msg[2];

	int packet_len =0;
	char pre_code;
	char touchpoint;

	char pid[5];
    char pt_flag[5];
	int posx[5];
	int posy[5];
	int posz[5];
	int syn_flag=0;
	uint8_t Rdbuf[50];
	int ret;

	int i,j=0;
	
	//printk(KERN_INFO "aur385_ts_poscheck is working\n");
	if(isupdateflag==1)
		return;

	msg[0].addr = priv->client->addr;
	msg[0].flags = I2C_M_RD;
	msg[0].len = 1;
	msg[0].scl_rate= AUR3852_I2C_SPEED;
	msg[0].buf = Rdbuf;
	ret = i2c_transfer(priv->client->adapter, msg, 1);

	packet_len =Rdbuf[0]&0x3f;
	//printk("packet_len = %d,chip_state=%d\n",packet_len,chip_state);

	if(packet_len)
	{
		msg[0].addr = priv->client->addr;
		msg[0].flags = I2C_M_RD;
		msg[0].len = packet_len+1; // ��һ��PACKET
		msg[0].scl_rate= AUR3852_I2C_SPEED;
		msg[0].buf = Rdbuf;
	  	ret = i2c_transfer(priv->client->adapter, msg, 1);


		if(chip_state ==NORMAL_PIONT_STATE)
		{

			  pre_code = Rdbuf[1];
			  touchpoint = Rdbuf[2];

			 // printk("pre_code = %d  touchpoint =%d \n",pre_code,touchpoint);
			  if(!touchpoint)
			  	goto out;

				for(i=0;i<touchpoint;i++)
					{
					pt_flag[i] = Rdbuf[3+9*i];
					pid[i]	= Rdbuf[4+9*i];
					//posx[i] = TS_MAX_X - ((Rdbuf[6+9*i] << 8) | Rdbuf[5+9*i]);
					//posy[i] = TS_MAX_Y - ((Rdbuf[8+9*i] << 8) | Rdbuf[7+9*i]);
					posx[i] = LCD_MAX_WIDTH-(LCD_MAX_WIDTH * ((Rdbuf[6+9*i] << 8) | Rdbuf[5+9*i]) / TS_MAX_X);
					posy[i] = LCD_MAX_HEIGH- (LCD_MAX_HEIGH * ((Rdbuf[8+9*i] << 8) | Rdbuf[7+9*i]) / TS_MAX_Y);
					posz[i] = ((Rdbuf[10+9*i] << 8) | Rdbuf[9+9*i]);
					//printk("11::pt_flag[%d] = 0x%x pid[%d]= 0x%x  posx = %d ,posy = %d\n", i,pt_flag[i],i,pid[i],posx[i],posy[i] );
					}

					for(i=0;i<touchpoint;i++)
						{
						if(pt_flag[i]==0xE0)
							{
								//printk("down!pid[i] is %d\n",pid[i]-1);
	 					        input_mt_slot(priv->input_dev, pid[i]-1);
	 		                    input_mt_report_slot_state(priv->input_dev, MT_TOOL_FINGER, true);
								//input_report_key(priv->input_dev, ABS_MT_TRACKING_ID, pid[i]);
								input_report_abs(priv->input_dev, ABS_MT_POSITION_X, posx[i]);
								input_report_abs(priv->input_dev, ABS_MT_POSITION_Y, posy[i]);
								input_report_abs(priv->input_dev, ABS_MT_TOUCH_MAJOR, 1);
								input_report_abs(priv->input_dev, ABS_MT_WIDTH_MAJOR, 0);
								//input_mt_sync(priv->input_dev);
								syn_flag=1;
								j++;
								//printk("22::pt_flag[%d] = 0x%x pid[%d]= 0x%x  posx = %d ,posy = %d\n", i,pt_flag[i],i,pid[i],posx[i],posy[i] );
							}

						}
						for(i=0;i<touchpoint;i++)
						{
							if(pt_flag[i]==0x20)
						  	{
							  //  printk("up!pid[i] is %d\n",pid[i]-1);
								  input_mt_slot(priv->input_dev, pid[i]-1);
					          	  input_report_abs(priv->input_dev, ABS_MT_TOUCH_MAJOR, 0); //Finger Size
					          	  input_mt_report_slot_state(priv->input_dev, MT_TOOL_FINGER, false);
								  syn_flag=1;
						  	}
						}
						if(syn_flag==1){
							  	input_sync(priv->input_dev);
							}
		}

	  if(chip_state == AUR_START_RSPD)
		{
			//printk("Rdbuf[0]=%d,Rdbuf[1]=%d\n",Rdbuf[0],Rdbuf[1]);
			if(Rdbuf[1] != 0x80)
			{
				printk("AUR3852 %s error,Rdbuf[0]=%d,Rdbuf[1]=%d\n",__FUNCTION__,Rdbuf[0],Rdbuf[1]);
				respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;
		}
#if 1
       if(chip_state == AUR_CHECK_ISP_VER)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_CHECK_ISP_VER error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

  		printk("AUR3852 ISP Version %d.%d.%d\n",Rdbuf[2],Rdbuf[3],Rdbuf[4]);

		}
		if(chip_state == AUR_READ_FLASHINFO)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_PPI error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

			//aur_flash_info->size = (Rdbuf[3]<<8 | Rdbuf[2]);
			//aur_flash_info->start_page = Rdbuf[4];
			//aur_flash_info->end_page = Rdbuf[5];
			//AUR_PARA_ADDR = (Rdbuf[3]<<8) | Rdbuf[2];
			//AUR_PARA_CNT  = Rdbuf[4];
		}
		/*if(chip_state == AUR_READ_CSP)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_CSP error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

			AUR_APROM_SIZE = (Rdbuf[3]<<8) | Rdbuf[2];
			AUR_PAGE_SIZE  = (Rdbuf[5]<<8) | Rdbuf[4];

		}*/
		if(chip_state == AUR_EREASY_FLASH)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_CSP error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

		}

		if(chip_state == AUR_WRITE_OPDF)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_CSP error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

		}
		if(chip_state == AUR_WRITE_OPPF)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_CSP error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

		}

		if(chip_state == AUR_GET_PP)
		{

			if(Rdbuf[1] != 0x80)
			{
			printk("AUR3852 AUR_READ_CSP error\n");
			respond_rsut= -1;
			}
			respond_rsut= 0;
			chip_state = NORMAL_PIONT_STATE;

		}
#endif
	out:
		;
		//if ((priv->use_irq) && (need_time_check))
		//	enable_irq(priv->irq);


			//if(need_time_check)
			//	hrtimer_start(&priv->timer, ktime_set(0, 100000000), HRTIMER_MODE_REL); //100 ms
	}


}

static irqreturn_t aur3852_ts_isr(int irq,void *dev_id)
{
	struct aur3852_ts_priv *priv=dev_id;
		//printk("aur3852_ts_isr\n");
	//disable_irq_nosync(priv->client->irq);
	need_time_check = 1;
	queue_work(aur3852_wq, &priv->work);

	return IRQ_HANDLED;
}


static int aur3852_ts_open(struct input_dev *dev)
{
	return 0;
}

static void aur3852_ts_close(struct input_dev *dev)
{
}


static int aur3852_ts_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	struct aur3852_ts_priv *priv;
	struct aur3852_platform_data *pdata = pdata = client->dev.platform_data;
  	int ret = 0;
	int i;
	unsigned char isp_ver_buf[6];
	unsigned char ver_buf[5];
	
	priv=kzalloc(sizeof(*priv),GFP_KERNEL);
	if (priv == NULL) {
		dev_set_drvdata(&client->dev, NULL);
                ret = -ENOMEM;
                goto err_alloc_data_failed;
        }

  INIT_WORK(&priv->work,aur3852_ts_work);

	priv->client = client;
	i2c_set_clientdata(client, priv);
	ts_aur3852_dev = priv;
	priv->use_irq=0;
	dev_set_drvdata(&client->dev, priv);

	priv->input_dev = input_allocate_device();
	if(priv->input_dev == NULL){
                ret = -ENOMEM;
                printk(KERN_ERR "aur3852_ts_probe: Failed to allocate input device\n");
                goto err_input_dev_alloc_failed;
	}
	priv->input_dev->evbit[0] = BIT_MASK(EV_KEY) | BIT_MASK(EV_ABS);

	__set_bit(INPUT_PROP_DIRECT, priv->input_dev->propbit);
	__set_bit(EV_ABS, priv->input_dev->evbit);

	input_mt_init_slots(priv->input_dev, 5);

	input_set_abs_params(priv->input_dev, ABS_X, TS_MIN_X, LCD_MAX_WIDTH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_Y, TS_MIN_Y, LCD_MAX_HEIGH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_HAT0X, TS_MIN_X, LCD_MAX_WIDTH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_HAT0Y, TS_MIN_Y, LCD_MAX_HEIGH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_MT_POSITION_X, TS_MIN_X, LCD_MAX_WIDTH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_MT_POSITION_Y, TS_MIN_Y, LCD_MAX_HEIGH, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_MT_TOUCH_MAJOR, 0, 255, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_MT_WIDTH_MAJOR, 0, 255, 0, 0);
	input_set_abs_params(priv->input_dev, ABS_MT_TRACKING_ID, 0, 10, 0, 0);


	priv->input_dev->name = AUR3852_I2C_TS_NAME;
	priv->input_dev->id.bustype = BUS_I2C;
	priv->input_dev->dev.parent = &client->dev;

	priv->input_dev->open = aur3852_ts_open;
	priv->input_dev->close = aur3852_ts_close;



	if (pdata->init_platform_hw)
		pdata->init_platform_hw();

	/*setup_timer(&timer, aur3852_ts_work, NULL);
	timer.expires = jiffies +HZ * 30;
	add_timer(&timer);*/
	msleep(1000);
#if 1
	Check_ISP_Version(ver_buf);
	if(ver_buf[0] >= 0xa0)//�ж�TP�Ƿ���ڹ̼�
	{//δ���ڹ̼�
		printk("The TP didnot have firmware!");
		printk("========begin to update the tp firmware==========\n");
		touchfirmwareupdate();
	}
	else
	{//���ڹ̼�,�жϹ̼��汾�¾�
		Check_ISP_AE_Version(isp_ver_buf);
		printk("ver[0]=%02x,ver[1]=%02x,ver[2]=%02x,ver[3]=%02x\n",isp_ver_buf[0],isp_ver_buf[1],isp_ver_buf[2],isp_ver_buf[3]);
		if((aur3852_data[29952]!=isp_ver_buf[0])||(aur3852_data[29953]!=isp_ver_buf[1]))//||(aur3852_data[29954]!=isp_ver_buf[2])||(aur3852_data[29955]!=isp_ver_buf[3]))								
		{//�ͺŲ��ԣ���������
			printk("�ͺŲ���,��Ҫ����\n");
			touchfirmwareupdate();
		}
		else
		{//
			for(i=0;i<4;i++)
			{
				if(aur3852_data[29954+i]>isp_ver_buf[2+i])
				{
					printk("�̼��и��£���Ҫ����\n");
					touchfirmwareupdate();
					//need update
					break;
				}
				else if(aur3852_data[29954+i]<isp_ver_buf[2+i])
				{
					printk("�̼��Ǿɵģ�����Ҫ����\n");
					break;
				//did not need update
				}
			}
		}
		printk("-------Do not need update firmware,it is ok--------\n");
	}
	//Check_ISP_Version(isp_ver_buf);
#endif
#if 0
	Check_ISP_AE_Version(isp_ver_buf);
	printk("ver[0]=%02x,ver[1]=%02x,ver[2]=%02x,ver[3]=%02x\n",isp_ver_buf[0],isp_ver_buf[1],isp_ver_buf[2],isp_ver_buf[3]);

	if((aur3852_data[29952]!=isp_ver_buf[0])||(aur3852_data[29953]!=isp_ver_buf[1])||(aur3852_data[29954]!=isp_ver_buf[2])||(aur3852_data[29955]!=isp_ver_buf[3]))
	{
		printk("========begin to update the tp firmware==========\n");
		touchfirmwareupdate();
	}
	else
	{
		printk("-------Do not need update firmware,it is ok--------\n");
	}
#endif
	ret = input_register_device(priv->input_dev);
	priv->irq = gpio_to_irq(client->irq);

  if (ret)
  	{
     printk(KERN_ERR "aur3852_ts_probe: Unable to register %s input device\n", priv->input_dev->name);
     goto err_input_register_device_failed;
    }

		client->irq = gpio_to_irq(client->irq);
		//printk("client->irq=%d\n", client->irq);
    if (client->irq) {
		ret = request_irq(client->irq, aur3852_ts_isr, IRQF_TRIGGER_FALLING, client->name, priv);
		if (ret != 0) {
				free_irq(client->irq, priv);
		}
		if (ret == 0)
			priv->use_irq = 1;
		else
			dev_err(&client->dev, "request_irq failed\n");
	}



	if (!priv->use_irq)
	{
		hrtimer_init(&priv->timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
		priv->timer.function = AUR3852_ts_timer_func;
		//hrtimer_start(&priv->timer, ktime_set(10, 0), HRTIMER_MODE_REL);
	}

	//device_init_wakeup(&client->dev, 1);
	printk(KERN_INFO "aur3852_probe: Start touchscreen %s is success\n", priv->input_dev->name);
	priv->early_suspend.suspend = aur3852_ts_suspend;
	priv->early_suspend.resume = aur3852_ts_resume;
	priv->early_suspend.level = EARLY_SUSPEND_LEVEL_BLANK_SCREEN - 1;
	register_early_suspend(&priv->early_suspend);

	wake_lock_init(&ts_update_wake_lock, WAKE_LOCK_SUSPEND, "ts_update_lock");

	msleep(50);
	AUR3852_REPORT_START();
	return 0;

err_input_register_device_failed:
        input_free_device(priv->input_dev);
err_input_dev_alloc_failed:
        kfree(priv);
err_alloc_data_failed:
return ret;

}


static int aur3852_ts_remove(struct i2c_client *client)
{
	struct aur3852_ts_priv *priv = i2c_get_clientdata(client);
	free_irq(priv->irq, priv);
	//hrtimer_cancel(&priv->timer);
	input_unregister_device(priv->input_dev);
	unregister_early_suspend(&priv->early_suspend);
	kfree(priv);
	//dev_set_drvdata(&client->dev, NULL);
 	return 0;
}




static const struct i2c_device_id aur3852_ts_id[] = {
	{ AUR3852_I2C_TS_NAME, 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, aur3852_ts_id);

static struct i2c_driver aur3852_ts_driver = {
	.driver = {
		.owner = THIS_MODULE,
		.name = "AUR3852_I2C_TS_NAME",
	 },
	.probe = aur3852_ts_probe,
	.remove = aur3852_ts_remove,
	.id_table = aur3852_ts_id,
};



static DRIVER_ATTR(aur3852_firmware_update, 0777, aur3852_firmware_state, aur3852_firmware_update);
static int __init aur3852_ts_init(void)
{
	int ret;

	aur3852_wq = create_singlethread_workqueue("aur3852_wq");

	if(!aur3852_wq)
		return -ENOMEM;
	ret = i2c_add_driver(&aur3852_ts_driver);
	if (ret)
	{
	    printk("Register aur3852_ts driver failed.\n");
	    return ret;
	}

	ret =driver_create_file(&aur3852_ts_driver.driver, &driver_attr_aur3852_firmware_update);
	ts_init_ok =1;
	return ret;
}

static void __exit aur3852_ts_exit(void)
{
	i2c_del_driver(&aur3852_ts_driver);

	driver_remove_file(&aur3852_ts_driver.driver, &driver_attr_aur3852_firmware_update);
	if (aur3852_wq)
		destroy_workqueue(aur3852_wq);
}

MODULE_DESCRIPTION("aur3852 Touchscreen Driver");
MODULE_AUTHOR("SKY<http://www.rock-chips.com>");
MODULE_LICENSE("GPL");

late_initcall(aur3852_ts_init);
module_exit(aur3852_ts_exit);
